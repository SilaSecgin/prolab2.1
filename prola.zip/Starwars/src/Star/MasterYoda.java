package Star;

public class MasterYoda {

}
