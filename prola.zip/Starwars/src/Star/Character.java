package Star;

public class Character implements Location {

	String ad;
	String t�r;
	int x,y; 
	
}
