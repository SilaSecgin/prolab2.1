package Star;

public class GoodCh {

}
