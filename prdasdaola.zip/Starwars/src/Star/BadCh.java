package Star;

public class BadCh {

}
