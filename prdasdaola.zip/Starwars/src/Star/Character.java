package Star;

import javax.xml.stream.Location;

public abstract class Character  implements  Location	 {

	String ad;
	String t�r;
	int x,y;
	public String getAd() {
		return ad;
	}
	public void setAd(String ad) {
		this.ad = ad;
	}
	public String getT�r() {
		return t�r;
	}
	public void setT�r(String t�r) {
		this.t�r = t�r;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	
	public Character(String ad, String t�r, int x, int y) {
		super();
		this.ad = ad;
		this.t�r = t�r;
		this.x = x;
		this.y = y;
	}
	
	
	
}
