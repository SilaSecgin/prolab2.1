package Star;

public class LukeSkywalker extends GoodCh{

}
