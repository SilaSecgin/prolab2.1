package Star;

public class DarthVader extends BadCh{

	
}
