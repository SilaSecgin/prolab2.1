package Star;

public class Stormtrooper extends BadCh{

}
