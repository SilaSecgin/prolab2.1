package Star;

public class GoodCh extends Character{
	
	

}
