package Star;

public class MasterYoda extends GoodCh{

}
